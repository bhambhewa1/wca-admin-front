

// Staging Url
// export const API_URL = "http://wca-backend.orientaloutsourcing.in";

// Live URL
export const API_URL = "http://localhost:5000"

