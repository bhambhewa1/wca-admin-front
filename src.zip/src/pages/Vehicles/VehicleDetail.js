import React from 'react'

const VehicleDetail = () => {
  return (
    <div>VehicleDetail</div>
  )
}

export default VehicleDetail