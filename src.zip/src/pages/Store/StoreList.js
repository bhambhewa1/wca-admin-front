import React from 'react'

const StoreList = () => {
  return (
    <div>StoreList</div>
  )
}

export default StoreList