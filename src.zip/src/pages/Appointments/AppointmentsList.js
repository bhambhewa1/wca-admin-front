import React from 'react'

const AppointmentsList = () => {
  return (
    <div>AppointmentsList</div>
  )
}

export default AppointmentsList