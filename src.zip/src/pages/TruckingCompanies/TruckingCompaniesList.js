import React from 'react'

const TruckingCompaniesList = () => {
  return (
    <div>TruckingCompaniesList</div>
  )
}

export default TruckingCompaniesList