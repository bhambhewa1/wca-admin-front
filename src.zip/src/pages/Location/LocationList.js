import React from 'react'

const LocationList = () => {
  return (
    <div>LocationList</div>
  )
}

export default LocationList